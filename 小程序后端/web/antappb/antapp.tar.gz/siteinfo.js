var siteinfo = {
    'acid': -1,
    'version': '1.0.0',
    'siteroot': 'http://www.abc.com/app/index.php',
    'apiroot': 'http://www.abc.com/addons/hj_mall/core/web/index.php?store_id=1&r=api/',
};
module.exports = siteinfo;