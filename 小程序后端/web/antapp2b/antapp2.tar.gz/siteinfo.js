var siteinfo = {
    'acid': -1,
    'version': '1.0.0',
    'siteroot': 'https://abc.com/app/index.php',
    'apiroot': 'https://hjmall.haoyunfa.net/web/index.php?store_id=6&r=api/',
};
module.exports = siteinfo;